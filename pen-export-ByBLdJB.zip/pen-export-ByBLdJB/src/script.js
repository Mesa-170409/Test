<script>

  function sayHello() {

    alert("สวัสดี! ยินดีต้อนรับ :)");

  }

</script>

<button onclick="sayHello()">คลิกที่นี่</button>